import React from "react";
export default function Subjects(){
  return (
    <div style={{maxWidth:900}}>
      <h2>Subjects</h2>
      <p>This page will list KCSE subjects and lessons (seed your Realtime DB to see content).</p>
    </div>
  )
}